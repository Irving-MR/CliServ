package socketserv;

import java.net.*;
import java.io.*;
import java.util.Scanner;

public class Socketserv {

    private Socket socket;
    private ServerSocket serverSocket;
    private DataInputStream bufferDeEntrada = null;
    private DataOutputStream bufferDeSalida = null;
    Scanner escaner = new Scanner(System.in);
    final String COMANDO_TERMINACION = "fin";
    final String COMANDO_LISTAR = "dir";

    //Envío de archivos
    byte[] receivedData;
    int in;
    String file;
    String dir;

    DataInputStream dis;
    DataOutputStream output;
    BufferedInputStream bis;
    BufferedOutputStream bos;

    public void levantarConexion(int puerto) {
        try {
            serverSocket = new ServerSocket(puerto);
            mostrarTexto("\nEsperando conexión en el puerto " + String.valueOf(puerto) + "...");
            socket = serverSocket.accept();
            mostrarTexto("Conexión establecida con: " + socket.getInetAddress().getHostName() + "\n\n");
            mostrarTexto("Ingrese fin para terminar el chat\nIngrese listar para mostrar una carpeta\n");
            mostrarTexto("Chat bidireccional\n\tServidor\n");
        } catch (Exception e) {
            mostrarTexto("Error al intentar conexión: " + e.getMessage());
            System.exit(0);
        }
    }

    public void flujos() {
        try {
            bufferDeEntrada = new DataInputStream(socket.getInputStream());
            bufferDeSalida = new DataOutputStream(socket.getOutputStream());
            bufferDeSalida.flush();
        } catch (IOException e) {
            mostrarTexto("Error en la conexión e intercambio de paquetes");
        }
    }

    public void enviarArchivo() {
        try {
            //Buffer de 1024 bytes
            receivedData = new byte[1024];
            System.out.println(receivedData);
            bis = new BufferedInputStream(socket.getInputStream());
            dis = new DataInputStream(socket.getInputStream());
            //Recibimos el nombre del fichero
            file = dis.readUTF();
            file = file.substring(file.indexOf('\\') + 1, file.length());
            //Para guardar fichero recibido
            bos = new BufferedOutputStream(new FileOutputStream(file));
            while ((in = bis.read(receivedData)) != -1) {
                bos.write(receivedData, 0, in);
            }
            bos.close();
            dis.close();
        } catch (IOException e) {
            System.err.println("Error al recibir el archivo: " + e.getMessage().toString());
        }
    }

    public void recibirDatos() {
        String st = "";
        String n = "";
        Scanner esc = new Scanner(System.in);
        String dirarch;
        try {
            do {
                st = (String) bufferDeEntrada.readUTF();
                mostrarTexto("\nServidor:  " + st);
                System.out.print("\n      Tú:  ");
            } while (!st.equals(COMANDO_TERMINACION));
        } catch (IOException e) {
            cerrarConexion();
        }
    }

    public void enviar(String s) {
        try {
            bufferDeSalida.writeUTF(s);
            bufferDeSalida.flush();
        } catch (IOException e) {
            mostrarTexto("Error en enviar: " + e.getMessage());
        }
    }

    public static void mostrarTexto(String s) {
        System.out.print(s);
    }

    public void escribirDatos() {
        while (true) {
            System.out.print("      Tú:  ");
            enviar(escaner.nextLine());
        }
    }

    public void cerrarConexion() {
        try {
            bufferDeEntrada.close();
            bufferDeSalida.close();
            socket.close();
        } catch (IOException e) {
            mostrarTexto("Excepción en cerrarConexion(): " + e.getMessage());
        } finally {
            mostrarTexto("Conversación finalizada....");
            System.exit(0);

        }
    }

    public void ejecutarConexion(int puerto) {
        Thread hilo = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        levantarConexion(puerto);
                        flujos();
                        recibirDatos();
                    } finally {
                        cerrarConexion();
                    }
                }
            }
        });
        hilo.start();
    }

    public void listarDirectorio(String archivo) {
        String sCarpAct = System.getProperty("user.dir");
        mostrarTexto("Carpeta del usuario = " + archivo);
        try {
            File carpeta = new File(archivo);
            String[] listado = carpeta.list();
            if (listado == null || listado.length == 0) {
                mostrarTexto("No hay elementos dentro de la carpeta actual");
                return;
            } else {
                for (int i = 0; i < listado.length; i++) {
                    mostrarTexto(listado[i]);
                }
            }
        } catch (Exception e) {
            mostrarTexto("No se encontró el directorio: " + e.getMessage().toString());
        }
    }

    public static void main(String[] args) {
        Socketserv s = new Socketserv();
        Scanner sc = new Scanner(System.in);

        mostrarTexto("Puerto:  ");
        String puerto = sc.nextLine();
        if (puerto.length() <= 0) {
            puerto = "5050";
        }
        s.ejecutarConexion(Integer.parseInt(puerto)); //Conexión bidireccional
        s.escribirDatos();
    }
}
