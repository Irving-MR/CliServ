package dirsocketsserver;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class DirSocketsServer {

    ServerSocket server;
    Socket connection;

    DataOutputStream output;
    BufferedInputStream bis;
    BufferedOutputStream bos;

    byte[] receivedData;
    int in;
    String file;
    Scanner esc = new Scanner(System.in);

    private Socket socket;
    private ServerSocket serverSocket;
    private DataInputStream bufferDeEntrada = null;
    private DataOutputStream bufferDeSalida = null;
    Scanner escaner = new Scanner(System.in);

    DataInputStream dis;

    public void mostrarTexto(String s) {
        System.out.println(s);
    }

    public void levantarConexion(int puerto) {
        try {
            serverSocket = new ServerSocket(puerto);
            mostrarTexto("\nEsperando conexión en el puerto " + String.valueOf(puerto) + "...");
            socket = serverSocket.accept();
            mostrarTexto("Conexión establecida con: " + socket.getInetAddress().getHostName() + "\n\n");

        } catch (Exception e) {
            mostrarTexto("Error al intentar conexión: " + e.getMessage());
            System.exit(0);
        }
    }

    public void flujos() {
        try {
            bufferDeEntrada = new DataInputStream(socket.getInputStream());
            bufferDeSalida = new DataOutputStream(socket.getOutputStream());
            bufferDeSalida.flush();
        } catch (IOException e) {
            mostrarTexto("Error en la conexión e intercambio de paquetes");
        }
    }

    public void cerrarConexion() {
        try {
            bufferDeEntrada.close();
            bufferDeSalida.close();
            socket.close();
        } catch (IOException e) {
            mostrarTexto("Excepción en cerrarConexion: " + e.getMessage());
        } finally {
            mostrarTexto("Conversación finalizada....");
            System.exit(0);

        }
    }

    public void ejecutarConexion(int puerto, String archivo) {
        Thread hilo = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        levantarConexion(puerto);
                        flujos();
                        enviarArchivo(archivo);
                    } finally {
                        cerrarConexion();
                    }
                }
            }
        });
        hilo.start();
    }

    public void enviarArchivo(String archivo) {
        String sCarpAct = System.getProperty("user.dir");
        mostrarTexto("Carpeta del usuario = " + archivo);
        try {
            File carpeta = new File(archivo);
            String[] listado = carpeta.list();
            if (listado == null || listado.length == 0) {
                mostrarTexto("No hay elementos dentro de la carpeta actual");
                return;
            } else {
                for (int i = 0; i < listado.length; i++) {
                    mostrarTexto(listado[i]);
                }
            }
        } catch (Exception e) {
            mostrarTexto("No se encontró el directorio: " + e.getMessage().toString());
        }
    }

    public static void main(String[] args) {
        DirSocketsServer s = new DirSocketsServer();
        Scanner sc = new Scanner(System.in);
        //s.mostrarTexto("La ruta por default: directorio de usuario");

        s.mostrarTexto("Puerto:  ");
        String puerto = sc.nextLine();
        if (puerto.length() <= 0) {
            puerto = "2005";
            s.mostrarTexto("El puerto default es 2005");
        }
        s.mostrarTexto("Introduce la dirección del directorio para listar: ");
        String dirarch = sc.nextLine();
        s.ejecutarConexion(Integer.parseInt(puerto), dirarch);
    }
}
