package dirsocketscliente;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class DirSocketsCliente {

    private Socket socket;
    private DataInputStream bufferDeEntrada = null;
    private DataOutputStream bufferDeSalida = null;
    Scanner teclado = new Scanner(System.in);

    DataInputStream input;

    BufferedInputStream bis;
    BufferedOutputStream bos;

    int in;
    byte[] byteArray;
    //Fichero a transferir
    String filename = null;

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";

    Scanner esc = new Scanner(System.in);

    public void mostrarTexto(String s) {
        System.out.println(s);
    }

    public void levantarConexion(String ip, int puerto) {
        try {
            socket = new Socket(ip, puerto);
            mostrarTexto("Conectado a :" + socket.getInetAddress().getHostName());
        } catch (Exception e) {
            mostrarTexto("Error al iniciar la conexión: " + e.getMessage());
            System.exit(0);
        }
    }

    public void abrirFlujos() {
        try {
            bufferDeEntrada = new DataInputStream(socket.getInputStream());
            bufferDeSalida = new DataOutputStream(socket.getOutputStream());
            bufferDeSalida.flush();
        } catch (IOException e) {
            mostrarTexto("Error en la conexión e intercambio de paquetes");
        }
    }

    public void cerrarConexion() {
        try {
            bufferDeEntrada.close();
            bufferDeSalida.close();
            socket.close();
            mostrarTexto("Conexión terminada");
        } catch (IOException e) {
            mostrarTexto("Error al cerrar conexion");
        } finally {
            System.exit(0);
        }
    }

    public void ejecutarConexion(String ip, int puerto, String archivo) {
        Thread hilo = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    levantarConexion(ip, puerto);
                    abrirFlujos();
                    enviarArchivo(archivo);
                } finally {
                    cerrarConexion();
                }
            }
        });
        hilo.start();
    }

    public void enviarArchivo(String archivo) {
        String sCarpAct = System.getProperty("user.dir");
        mostrarTexto("Carpeta del usuario = " + archivo);
        try {
            File carpeta = new File(archivo);
            String[] listado = carpeta.list();
            if (listado == null || listado.length == 0) {
                mostrarTexto("No hay elementos dentro de la carpeta actual");
                return;
            } else {
                for (int i = 0; i < listado.length; i++) {
                    mostrarTexto(listado[i]);
                }
            }
        } catch (Exception e) {
            mostrarTexto("No se encontró el directorio: " + e.getMessage().toString());
        }
    }

    public static void main(String[] args) {
        Scanner esc = new Scanner(System.in);
        DirSocketsCliente s = new DirSocketsCliente();

        Scanner escaner = new Scanner(System.in);

        //Especificación de IP
        s.mostrarTexto("IP:  ");
        String ip = escaner.next();
        if (ip.length() <= 0) {
            s.mostrarTexto("Conectado a localhost ");
            ip = "localhost";
        }
        //Especificación del puerto
        s.mostrarTexto("Puerto:  ");
        String puerto = escaner.next();
        if (puerto.length() <= 0) {
            s.mostrarTexto("El puerto default es 2005");
            puerto = "2005";
        }

        s.mostrarTexto("Introduce la dirección del directorio para listar: ");
        String dirarch = esc.nextLine();
        s.ejecutarConexion(ip, Integer.parseInt(puerto), dirarch);
    }
}
