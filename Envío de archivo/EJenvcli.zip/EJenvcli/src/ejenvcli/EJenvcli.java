package ejenvcli;

import java.net.*;
import java.io.*;
import java.util.Scanner;

public class EJenvcli {
    
    private Socket socket;
    private DataInputStream bufferDeEntrada = null;
    private DataOutputStream bufferDeSalida = null;
    Scanner teclado = new Scanner(System.in);

    DataInputStream input;

    BufferedInputStream bis;
    BufferedOutputStream bos;

    int in;
    byte[] byteArray;
    //Fichero a transferir
    String filename = null;

    Scanner esc = new Scanner(System.in);

    public void mostrarTexto(String s) {
        System.out.println(s);
    }
    
    public void levantarConexion(String ip, int puerto) {
        try {
            socket = new Socket(ip, puerto);
            mostrarTexto("Conectado a :" + socket.getInetAddress().getHostName());
        } catch (Exception e) {
            mostrarTexto("Error al iniciar la conexión: " + e.getMessage());
            System.exit(0);
        }
    }
    
    public void abrirFlujos() {
        try {
            bufferDeEntrada = new DataInputStream(socket.getInputStream());
            bufferDeSalida = new DataOutputStream(socket.getOutputStream());
            bufferDeSalida.flush();
        } catch (IOException e) {
            mostrarTexto("Error en la conexión e intercambio de paquetes");
        }
    }
    
    public void cerrarConexion() {
        try {
            bufferDeEntrada.close();
            bufferDeSalida.close();
            socket.close();
            mostrarTexto("Conexión terminada");
        } catch (IOException e) {
            mostrarTexto("Error al cerrar conexion");
        } finally {
            System.exit(0);
        }
    }
    
    public void ejecutarConexion(String ip, int puerto, String archivo) {
        Thread hilo = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    levantarConexion(ip, puerto);
                    abrirFlujos();
                    enviarArchivo(archivo);
                } finally {
                    cerrarConexion();
                }
            }
        });
        hilo.start();
    }

    public void enviarArchivo(String archivo) {
        try {
            final File localFile = new File(archivo);
            bis = new BufferedInputStream(new FileInputStream(localFile));
            bos = new BufferedOutputStream(socket.getOutputStream());
            //Enviamos el nombre del fichero
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
            dos.writeUTF(localFile.getName());
            //Enviamos el fichero
            byteArray = new byte[8192];
            while ((in = bis.read(byteArray)) != -1) {
                bos.write(byteArray, 0, in);
            }

            bis.close();
            bos.close();
            mostrarTexto("Archivo enviado");

        } catch (IOException e) {
            mostrarTexto("El archivo no se pudo mandar: " + e.getMessage().toString());
        }
    }

    public static void main(String[] args) {
        Scanner esc = new Scanner(System.in);
        EJenvcli s = new EJenvcli();
        
        Scanner escaner = new Scanner(System.in);
        
        //Especificación de IP
        s.mostrarTexto("IP:  ");
        String ip = escaner.next();
        if (ip.length() <= 0) {
            s.mostrarTexto("Conectado a localhost ");
            ip = "localhost";
        }
        //Especificación del puerto
        s.mostrarTexto("Puerto:  ");
        String puerto = escaner.next();
        if (puerto.length() <= 0) {
            s.mostrarTexto("El puerto default es 2005");
            puerto = "2005";
        }

        s.mostrarTexto("Introduce la dirección del archivo a enviar: ");
        String dirarch = esc.nextLine();
        s.ejecutarConexion(ip, Integer.parseInt(puerto), dirarch);
    }
}
