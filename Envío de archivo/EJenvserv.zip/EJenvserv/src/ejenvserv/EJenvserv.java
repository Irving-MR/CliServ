package ejenvserv;

import java.net.*;
import java.io.*;
import java.util.*;

class EJenvserv {

    ServerSocket server;
    Socket connection;

    DataOutputStream output;
    BufferedInputStream bis;
    BufferedOutputStream bos;

    byte[] receivedData;
    int in;
    String file;
    Scanner esc = new Scanner(System.in);

    private Socket socket;
    private ServerSocket serverSocket;
    private DataInputStream bufferDeEntrada = null;
    private DataOutputStream bufferDeSalida = null;
    Scanner escaner = new Scanner(System.in);

    DataInputStream dis;

    public void mostrarTexto(String s) {
        System.out.println(s);
    }

    public void levantarConexion(int puerto) {
        try {
            serverSocket = new ServerSocket(puerto);
            mostrarTexto("\nEsperando conexión en el puerto " + String.valueOf(puerto) + "...");
            socket = serverSocket.accept();
            mostrarTexto("Conexión establecida con: " + socket.getInetAddress().getHostName() + "\n\n");

        } catch (Exception e) {
            mostrarTexto("Error al intentar conexión: " + e.getMessage());
            System.exit(0);
        }
    }

    public void flujos() {
        try {
            bufferDeEntrada = new DataInputStream(socket.getInputStream());
            bufferDeSalida = new DataOutputStream(socket.getOutputStream());
            bufferDeSalida.flush();
        } catch (IOException e) {
            mostrarTexto("Error en la conexión e intercambio de paquetes");
        }
    }

    public void cerrarConexion() {
        try {
            bufferDeEntrada.close();
            bufferDeSalida.close();
            socket.close();
        } catch (IOException e) {
            mostrarTexto("Excepción en cerrarConexion: " + e.getMessage());
        } finally {
            mostrarTexto("Conversación finalizada....");
            System.exit(0);

        }
    }

    public void ejecutarConexion(int puerto) {
        Thread hilo = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        levantarConexion(puerto);
                        flujos();
                        recibirArchivo();
                    } finally {
                        cerrarConexion();
                    }
                }
            }
        });
        hilo.start();
    }

    public void recibirArchivo() {
        try {
            while (true) {
                //Aceptar conexiones
                connection = serverSocket.accept();
                //Buffer de 1024 bytes
                receivedData = new byte[1024];
                bis = new BufferedInputStream(connection.getInputStream());
                DataInputStream dis = new DataInputStream(connection.getInputStream());
                //Recibimos el nombre del fichero
                file = dis.readUTF();
                file = file.substring(file.indexOf('\\') + 1, file.length());
                //Para guardar fichero recibido
                bos = new BufferedOutputStream(new FileOutputStream(file));
                while ((in = bis.read(receivedData)) != -1) {
                    bos.write(receivedData, 0, in);
                }
                bos.close();
                dis.close();
            }
        } catch (IOException e) {
            mostrarTexto("Error al recibir el archivo: " + e.getMessage().toString());
        }
    }

    public static void main(String[] args) {
        EJenvserv s = new EJenvserv();
        Scanner sc = new Scanner(System.in);
        s.mostrarTexto("La ruta por default: directorio de usuario");
        
        s.mostrarTexto("Puerto:  ");
        String puerto = sc.nextLine();
        if (puerto.length() <= 0) {
            puerto = "2005";
            s.mostrarTexto("El puerto default es 2005");
        }
        s.ejecutarConexion(Integer.parseInt(puerto));
    }
}
